// copyright 2022 Isabella Buranich
#include <iostream>
#include <string>
#include <array>
#include <fstream>
#include <sstream>
#include <math.h>

using std::string;
using std::cout;


//initialized variables

string inputfilename = "input.txt";
string outputfilename= "output.txt";

const int size=3; //# of liens in input file
string data[size];

//function prototypes
int main();
void readInput(string);


   //////////////////////////////////////////

int main() {
void readInput(inputfilename, data[size]);
 return 0;  
}

void readInput(string inputfilename,string data[size]) {

  std::ifstream in(inputfilename);
  int i = 0;
  int j=0;
  if (in.is_open()) {
    string line;
    string wline;
    while (getline(in, line,'\n')) {
       std::stringstream wholeline(wline);
        while (getline(wholeline, line, ' ')) {
data[i][j] = line;
// problem solving output line
// std::cout <<  "\nline:" << line << "\n" << i << j 
// << "\ndataij:"<< data[i][j] << std::endl;
        j++;}
  i++;
  }
  if (j!=rows || i!=cols){
  std::cout<<"error file index has changed please restart process"<< std::endl;
  }

}
}