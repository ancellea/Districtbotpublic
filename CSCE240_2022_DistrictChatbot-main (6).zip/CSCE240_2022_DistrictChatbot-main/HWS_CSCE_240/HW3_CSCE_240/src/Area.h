#ifndef AREA_H_
#define AREA_H_

#include <iostream>
#include<string>

using namespace std;
const int rows2=3;
const int cols2=4;

int areaCircle(int);
int areaRectangle(int,int);
int areaTriangle(int,int,int);

class Area{
    
    string data[rows2][cols2];
    string test;
    int area;

public:
    Area();
    //Area(string data[rows2][cols2]);
    ~Area();
    //void getArea(string data[rows2][cols2]);
        
    

  Area getArea(string data[rows2][cols2]);

 };
#endif 