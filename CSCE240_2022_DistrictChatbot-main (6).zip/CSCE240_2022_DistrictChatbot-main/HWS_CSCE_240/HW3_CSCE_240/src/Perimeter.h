#ifndef PERIMETER_H_
#define PERIMETER_H_

#include <iostream>
#include<string>

using namespace std;
const int rows1=3;
    const int cols1=4;
class Perimeter{
    
    string data[rows1][cols1];
    string test;
    int perimeter;

public:

    Perimeter(string data[rows1][cols1]);
    ~Perimeter();
    Perimeter getPerimeter(string data[rows1][cols1]);
};

#endif 