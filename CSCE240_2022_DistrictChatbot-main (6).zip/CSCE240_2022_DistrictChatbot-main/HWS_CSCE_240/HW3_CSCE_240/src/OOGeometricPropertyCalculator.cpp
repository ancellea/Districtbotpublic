 #include "Area.h"
 #include "Perimeter.h"

const int rows3=3;
const int cols3=4;
const int pi=3.1415;
string data2[rows3][cols3];

/*int areaCircle(int);
int perimeterCircle(int);
int areaRectangle(int,int);
int perimeterRectangle(int,int);
int areaTriangle(int,int,int);
int perimeterTriangle(int,int,int);

 /* void Perimeter::getPerimeter(string data2[rows3][cols3]){    
 string test;
 int perimeter;
        for(int i=0;i<rows3; i++)
        {
           test = data2[i][1];
            if(test=="CIRCLE")//circle
            {
                perimeter=perimeterCircle(std::stoi(data2[i][2]));
                 data2[i][1]="CIRCLE PERIMETER:"+perimeter;
            }
             else if(test=="RECTANGLE")//rectangle
            {
                 perimeter=perimeterRectangle(std::stoi(data2[i][2]),std::stoi(data2[i][3]));
                data2[i][1]="RECTANGLE PERIMETER:"+perimeter;
            }
    
             else if(test=="TRIANGLE")//triangle
            {
               perimeter=perimeterTriangle(std::stoi(data2[i][2]),std::stoi(data2[i][3]),std::stoi(data2[i][4]));
                data2[i][1]="TRIANGLE PERIMETER:"+perimeter;
            }
    
            else{
                std::cout<<"error with calculations, restart"<<std::endl;
            }
        }
        
    

}*/

 /*  void Area::getArea(string data2[rows3][cols3])
{

        std::cout<<"getArea is running"<<std::endl;
        string test;
        int area;
        for(int i=0;i<rows3; i++)
        {
            test=data2[i][1];
            if(test=="CIRCLE")//circle
            {
                area=areaCircle(std::stoi(data2[i][2]));
                data2[i][1]="CIRCLE AREA:"+area;
                std::cout<<data2[i][1]<<std::endl;
            }
            else if(test=="RECTANGLE")//rectangle
            {
                area=areaRectangle(std::stoi(data2[i][2]),std::stoi(data2[i][3]));
                 data2[i][1]="RECTANGLE AREA:"+area;
                 std::cout<<data2[i][1]<<std::endl;
                 } 
             else if(test=="TRIANGLE")//triangle
            {
                area=areaTriangle(std::stoi(data2[i][2]),std::stoi(data2[i][3]),std::stoi(data2[i][4]));
                 data2[i][1]="TRIANGLE AREA:"+area;
                 std::cout<<data2[i][1]<<std::endl;
            } 
        }
    }*/
/*
int areaCircle(int radius){
    int area=pi*radius*radius;
    return area;
}
int perimeterCircle(int radius){
    int perimeter=radius*2*pi;
    return perimeter;
}
int areaRectangle(int width, int length){
    int area=length*width;
    return area;
}
int perimeterRectangle(int width, int length){
int perimeter=length+length+width+width;
    return perimeter;
}
int areaTriangle(int side1,int side2,int side3){
    int s=(side1+side2+side3)/2;
    int area=sqrt(s*(s-side1)*(s-side2)*(s-side3));
    return area;
}
int perimeterTriangle(int side1,int side2,int side3){
    int perimeter=side1+side2+side3;
    return perimeter;
}
*/



  

