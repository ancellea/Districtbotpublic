// copyright 2022 Isabella Buranich
#include <iostream>
#include <string>
#include <array>
#include <fstream>
#include <sstream>

using std::string;
using std::cout;

string inputfilename = "../data/GmailHeader.txt";
int main();
void readInput(string, string);
const int size = 17;

int main ()
{
    bool test = readUsers(string inputfilename, string data[size])
    std::string str("1231");
    std::regex r("^(\\d)");
    std::smatch m;
    std::regex_search(str, m, r);
    for(auto v: m) std::cout << v << std::endl;
}



bool readUsers(string fh, string data[ROWS][COLS]) {
bool ans = false;
  std::ifstream in(fh);
  int i = 0;
  int j = 0;
  if (in.is_open()) {
    string line;
    string wline;
     ans = true;
    while (getline(in, wline,'\n')) {
       std::stringstream wholeline(wline);
        while (getline(wholeline, line, ',')) {
data[i][j] = line;
// problem solving output line
// std::cout <<  "\nline:" << line << "\n" << i << j 
// << "\ndataij:"<< data[i][j] << std::endl;
if(j < 3) {
  j++;}
else {j = 0;}
    }
j=0;
  i++;
  }
  }
return ans;

}