// copyright 2022 Isabella Buranich
#include <iostream>
#include "./calculator.h"
#include <string>
#include <array>
#include <fstream>
#include <sstream>
#include <math.h>

using std::string;
using std::cout;

string inputfilename = "../data/input.txt";
string outputfilename= "../data/output.txt";
/*
int x =  filesizerow(inputfilename);
int y = filesizecol(inputfilename);
int const rows = filesizerow(inputfilename);

int const cols = filesizerow(inputfilename);
*/
const int rows=3;
const int cols=4;
string data[rows][cols];
const int pi=3.1415;
string choice;
bool choicebool;

//function prototypes
int main();
int filesizerow(string);
int filesizecol(string);
void readInput(string, string);
void getArea(string);// data[rows][cols]);
void getPerimeter(string);// data[rows][cols]);
void makeoutput(string, string);// data[rows][cols]);
int areaCircle(int);
int perimeterCircle(int);
int areaRectangle(int,int);
int perimeterRectangle(int,int);
int areaTriangle(int,int,int);
int perimeterTriangle(int,int,int);

   //////////////////////////////////////////

int main() {
void readInput(string inputfilename, string data[rows][cols]);

//user's choice
bool read = false;
while(read == false){
std::cout<<"Do you want to calculate areas or perimeters\n(enter 1 for area or 2 for perimeter)";
std::cin >> choice;
//std::cout<<choice<<"this was your choice"<<std::endl;
if(choice.compare("1")==0){ //(choice.find('a')) || (choice.find('A')) || 
std::cout<<"you choose area"<<std::endl;
    read=true;
    void getArea(string data[rows][cols]);
    
}
else if (choice.compare("2")==0){ //(choice.find('p')) || (choice.find('P'))|| 
std::cout<<"you choose perimeter"<<std::endl;
    read=true;
    void getPerimeter(string data[rows][cols]);
}
else
{
std::cout<<"\nerror invalid input, please enter either 1 for area or  2 perimeter"<< std::endl;
std::cin >>choice;
}
}


//continue to output
void makeoutput(string outputfilename, string data[rows][cols]);
 return 0;  
}

int filesizerow(string inputfilename) {
    int x=0;
    bool test = false;
  std::ifstream in(inputfilename);
  int i = 0;
  int j = 0;
  if (in.is_open()) {
    string line;
    string wline;
     test = true;
    while (getline(in, wline,'\n')) {
       std::stringstream wholeline(wline);
       i++;
        while (getline(wholeline, line, ',')) {
j++;
// problem solving output line
// std::cout <<  "\nline:" << line << "\n" << i << j 
// << "\ndataij:"<< data[i][j] << std::endl;


  }
    }
int x=j;
int y=i;
if (test == false) {
      std::cout<<"error with file please check format and restart"<<std::endl;
  }
  
}
return x;
}

int filesizecol(string inputfilename) {
    int y=0;
    bool test = false;
  std::ifstream in2(inputfilename);
  int i = 0;
  int j = 0;
  if (in2.is_open()) {
    string line;
    string wline;
     test = true;
    while (getline(in2, wline,'\n')) {
       std::stringstream wholeline(wline);
       i++;
        while (getline(wholeline, line, ',')) {
j++;
// problem solving output line
// std::cout <<  "\nline:" << line << "\n" << i << j 
// << "\ndataij:"<< data[i][j] << std::endl;


  }
    }
int x=j;
int y=i;
if (test == false) {
      std::cout<<"error with file please check format and restart"<<std::endl;
  }
  
}
return y;
}


void readInput(string inputfilename, string data[rows][cols]) {

  std::ifstream in(inputfilename);
  int i = 0;
  int j=0;
  if (in.is_open()) {
    string line;
    string wline;
    while (getline(in, line,'\n')) {
       std::stringstream wholeline(wline);
        while (getline(wholeline, line, ' ')) {
data[i][j] = line;
// problem solving output line
// std::cout <<  "\nline:" << line << "\n" << i << j 
// << "\ndataij:"<< data[i][j] << std::endl;
        j++;}
  i++;
  }
  if (j!=rows || i!=cols){
  std::cout<<"error file index has changed please restart process"<< std::endl;
  }

}
}

int areaCircle(int radius){
    int area=pi*radius*radius;
    return area;
}
int perimeterCircle(int radius){
    int perimeter=radius*2*pi;
    return perimeter;
}
int areaRectangle(int width, int length){
    int area=length*width;
    return area;
}
int perimeterRectangle(int width, int length){
int perimeter=length+length+width+width;
    return perimeter;
}
int areaTriangle(int side1,int side2,int side3){
    int s=(side1+side2+side3)/2;
    int area=sqrt(s*(s-side1)*(s-side2)*(s-side3));
    return area;
}
int perimeterTriangle(int side1,int side2,int side3){
    int perimeter=side1+side2+side3;
    return perimeter;
}

    void getArea(string data[rows][cols]){
        std::cout<<"getArea is running"<<std::endl;
        string test;
        int area;
        for(int i=0;i<rows; i++)
        {
            test=data[i][1];
            if(test=="CIRCLE")//circle
            {
                area=areaCircle(std::stoi(data[i][2]));
                data[i][1]="CIRCLE AREA:"+area;
                std::cout<<data[i][1]<<std::endl;
            }
            else if(test=="RECTANGLE")//rectangle
            {
                area=areaRectangle(std::stoi(data[i][2]),std::stoi(data[i][3]));
                 data[i][1]="RECTANGLE AREA:"+area;
                 std::cout<<data[i][1]<<std::endl;
                 } 
             else if(test=="TRIANGLE")//triangle
            {
                area=areaTriangle(std::stoi(data[i][2]),std::stoi(data[i][3]),std::stoi(data[i][4]));
                 data[i][1]="TRIANGLE AREA:"+area;
                 std::cout<<data[i][1]<<std::endl;
            } 
        }
    }

    void getPerimeter(string data[rows][cols]){
 
 string test;
 int perimeter;
        for(int i=0;i<rows; i++)
        {
           test = data[i][1];
            if(test=="CIRCLE")//circle
            {
                perimeter=perimeterCircle(std::stoi(data[i][2]));
                 data[i][1]="CIRCLE PERIMETER:"+perimeter;
            }
             else if(test=="RECTANGLE")//rectangle
            {
                 perimeter=perimeterRectangle(std::stoi(data[i][2]),std::stoi(data[i][3]));
                data[i][1]="RECTANGLE PERIMETER:"+perimeter;
            }
    
             else if(test=="TRIANGLE")//triangle
            {
               perimeter=perimeterTriangle(std::stoi(data[i][2]),std::stoi(data[i][3]),std::stoi(data[i][4]));
                data[i][1]="TRIANGLE PERIMETER:"+perimeter;
            }
    
            else{
                std::cout<<"error with calculations, restart"<<std::endl;
            }
        }
        
    }

void makeoutput(string outputfilename, string data[rows][cols]){
    
    std::ofstream file;
  file.open (outputfilename);
for(int i=0;i<rows;i++){
      file<<data[i][1];
}
  file.close();
}

  

