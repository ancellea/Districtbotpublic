// Copyright 2021 Isabella Buranich
// Modified from template code @coleca24 GitHub
#ifndef LOGIN_H_
#define LOGIN_H_

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>

using std::string;
using std::cout;

const int COLS = 4;
const int ROWS = 5;

// TODO(commit 1): Commit #1 functions
void printUsers(const string data[ROWS][COLS]);
bool readUsers(string fh, string data[ROWS][COLS]);
char displayOptions();
bool validateOption(char option);
void executeOption(char option, string data[ROWS][COLS], string);
int searchForUser(string name, const string data[ROWS][COLS]);

// TODO(commit 2): Commit #2 functions
int findAllUsers(string title, const string data[ROWS][COLS]);
bool deleteUser(string name, string data[ROWS][COLS], string fh);
string generatePassword();
string generateEmail(string name);
int checkEmpty(const string data[ROWS][COLS]);
void addUser(int index, string name, string title,
             string data[ROWS][COLS], string fh);

void editcsvline(string newline, int row, string data[ROWS][COLS], string fh);
// (commit 1): Commit #1 functions

bool readUsers(string fh, string data[ROWS][COLS]) {
bool ans = false;
  std::ifstream in(fh);
  int i = 0;
  int j = 0;
  if (in.is_open()) {
    string line;
    string wline;
     ans = true;
    while (getline(in, wline,'\n')) {
       std::stringstream wholeline(wline);
        while (getline(wholeline, line, ',')) {
data[i][j] = line;
// problem solving output line
// std::cout <<  "\nline:" << line << "\n" << i << j 
// << "\ndataij:"<< data[i][j] << std::endl;
if(j < 3) {
  j++;}
else {j = 0;}
    }
j=0;
  i++;
  }
  }
return ans;

}

void printUsers(const string data[ROWS][COLS]) {
     int a = 0;
     int b = 0;

  while (a < 5) {
    b=0;
    while (b <= 3) {
 // std::cout << a << b << "\ndatais:\n" << data[a,b] << std::endl; //testing  line
 std::cout << data[a][b];
 if(b!=3)
 {
   std::cout <<",    ";
 }
  b++;
    }
    std::cout << "\n";
    a++;
    }
 

  return;
}
char displayOptions() {
  char choice;
  cout << "\nPlease Choose one of the following options:\nP(or p): Print Data\nS(or s): Search data by name\nF(or f): Find all in data with a certain job title\nA(or a): Add a new user\nD(or d): Delete an existing user\nE(or e): End Session\n";
  std::cin >> choice;
  return choice;
}
bool validateOption(char option) {
  
 switch(option) {
   case 'a': case 'A': case 'e': case 'E': case 'p': case 'P': case 's': case 'S': case 'f': case 'F': case 'd': case 'D':
   return true;
   break;
    default:
    return false;
    break;
}
}
void executeOption(char option, string data[ROWS][COLS], string fh) {
 int test;
 string name;
 string title;
  switch(option) {
     //execute E
    case 'e': case 'E':
//we don't have to do anything
   break;
    //execute p
    case 'p': case 'P':
  printUsers(data);
   break;
    //execute S
   case 's': case 'S':
 
   cout<<"Enter the name to be searched"<<std::endl;
     std::cin>>std::ws;//avoid errors
      getline(std::cin, name);
   
   
  //std::cin>>name; //doesn't work
  searchForUser(name,data);
   break;
   //execute F
    case 'f': case 'F':
   
   cout<<"Enter the job title to be searched"<<std::endl;
   std::cin>>title;
  findAllUsers(title,data);
   break;
    //execute A
    case 'a': case 'A':
    //index=1;//change later
test=checkEmpty(data);
if(test<0)
{
  cout<<"\nDatabase is full please delete a user." <<std::endl;
}
else{
  
  cout<<"Enter the name"<<std::endl;
   std::cin>>std::ws;//avoid errors
    getline(std::cin, name);
    
  //std::cin>>name; //doesn't work
    
   cout<<"Enter the job title"<<std::endl;
   std::cin>>title;
  addUser(test,name,title,data,fh);
}

 
   break;
   //execute D
   case 'd': case 'D':
 
   cout<<"Enter the name to be deleted"<<std::endl;
    std::cin>>std::ws;//avoid errors
   getline(std::cin, name);
   
 deleteUser(name, data,fh);
   break;
    default:
    cout<<"error execution failed";
    break;
  }
  return;
}
int searchForUser(string name, const string data[ROWS][COLS]) {
  int i=0;
  bool test;
  int ans = -1;
  while(i<=ROWS)
  {
  //[i][0]
  if(data[i][0]==name){
    //cout<<i;//testing line
  ans= i;//row number
  }
  
  i++;
  }
  if(ans>1)
  {
  printf("User found at index %d",ans);
  }
  else{
    cout<<"User does not exist";
  }
  return ans;
}

//(commit 2): Commit #2 functions
int findAllUsers(string title, const string data[ROWS][COLS]) {
  int a=0;
  bool test;
  int ans = 0;
  while(a<=ROWS)
  {
  //[i][0]
  if(data[a][3]==title){
    //cout<<i;//testing line
  ans= ans+1;//total sum of users
  }
  
  a++;
  }
   if(ans>1)
  {
  printf("There was %d users with that job title.",ans);
  }
  else{
    cout<<"There are no users with that job title.";
  }
  return ans;
}








bool deleteUser(string name, string data[ROWS][COLS], string fh) {
  bool ans = true;
  int location =  searchForUser(name,data);
  cout<<location;
  
    string nullLine = "NULL,NULL,NULL,NULL";
    //void editcsvline(string newline, int row, string data[ROWS][COLS],string fh);
editcsvline(nullLine,location,data,fh);
readUsers(fh,data);
  if(location==-1)
  {ans =false;}
  return ans;
}
string generatePassword() {
  char Lalphabet[26]={'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
 char Ualphabet[26]={'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
 char numbers[10]={'0','1','2','3','4','5','6','7','8','9'};
srand (time(NULL));
int r;
int placecap= (rand()%8);
int placenumber=(rand()%8);
string password="";
while(placecap==placenumber)
{
  placenumber=(rand()%8);
}
 for(int i=0;i<8;)
 {
   if(i==placenumber)
   {

     password+=numbers[rand()%10];
   }
   else
   {
   r=(rand()%26);
   if(i==placecap)
   {
     password+=Ualphabet[r];
   }
   else{
     password+=Lalphabet[r];
   }
   }
   i++;
   
 }

  return password;
}
string generateEmail(string name) {
  string email="";
   string line;
       std::stringstream wholename(name);
        getline(wholename,line,' ');
  email+=line;
  getline(wholename,line,' ');
  email+=line;
  email+="@email.com";
  cout<<email;
  return email;
}
int checkEmpty(const string data[ROWS][COLS]) {
 int i=0;
  bool test;
  int ans = -1;
  while(i<=ROWS && ans <0)
  {
  //[i][0]
  if(data[i][0]=="NULL"){
    //cout<<i;//testing line
  ans= i;//row number
  }
  
  i++;
  }
  return ans;
}
void addUser(int index, string name, string title,
             string data[ROWS][COLS], string fh) {
                string newline="";
 string password=generatePassword();
 string email=generateEmail(name);
 newline+=name;
 newline+=",";
 newline+=email;
 newline+=",";
 newline+=password;
 newline+=",";
 newline+=title;
 editcsvline(newline,index,data,fh);
 readUsers(fh,data);
  return;
}
void editcsvline(string newline,int row, string data[ROWS][COLS],string fh)
{
  newline+="\n";
 string lines[5];
 lines[row]=newline;



 std::ifstream in(fh);
  int i = 0;
  int j = 0;
  if (in.is_open()){
    string line;
    string wline;
    while(getline(in, wline,'\n')) {
      
data[i][j]=wline;
if(i!=row)
{
  string currentline=wline;
  currentline+="\n";
  lines[i]=currentline; 
}

//problem solving output line
//std::cout <<  "\nline:" << line << "\n" << i << j << "\ndataij:"<< data[i][j] << std::endl;

  i++;
  }
  }
in.close();



//out<<"testing";
//out<<newline;
std::ofstream out(fh);

for(int z=0;z<5;)
{
out<<lines[z];
z++;
}
out.close();


}

#endif  // LOGIN_H_
