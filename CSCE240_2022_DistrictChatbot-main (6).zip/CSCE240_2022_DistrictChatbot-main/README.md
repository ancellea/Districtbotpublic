# CSCE240_2022_DistrictChatbot
# Created by Isabella Buranich
# intended for CSCE 240 Spring 2022
# Should contain Homework and project progress and files.
# To start project enter folder Project1 and run Runme.sh you can type
# ./Runme.sh
# into terminal and it should all run.
# The project uses shell script, python, and c++.
