#include <iostream>
//#include <windows.h>
//#include <wininet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define HTTP_USER_AGENT "HTTPRIP"
#define BUFFER_SIZE 512

void usage(void);
void die(const char *message);

const char http[] = "HTTP";

int main(int argc, char **argv)
{
HANDLE file;
SECURITY_ATTRIBUTES sa;
HINTERNET internet;
HINTERNET url;
char *requesturl = NULL;
char *outputfile = NULL;
char *buf = NULL;
DWORD bytesread;
DWORD byteswritten;
int k;
int usestdout = 0;

if (argc == 2)
// user wants data directed to stdout
usestdout = 1;
else if (argc != 3)
usage();

requesturl = argv[1];

if (!usestdout)
outputfile = argv[2];

// validate protocol -- first 4 alphas should be http, case insensitive
for (k = 0; k < 4; k++)
if (requesturl[k] != http[k] && requesturl[k] != (char)(http[k] + 32))
die("Invalid url");

if (!usestdout)
{
file = CreateFile(outputfile,
GENERIC_WRITE,
FILE_SHARE_READ,
NULL,
CREATE_ALWAYS,
FILE_ATTRIBUTE_NORMAL,
NULL);
if (file == INVALID_HANDLE_VALUE)
die("CreateFile()");
}

printf("Opening connection...\n");
internet = InternetOpen(HTTP_USER_AGENT,
INTERNET_OPEN_TYPE_PRECONFIG,
NULL,
NULL,
0);
if (internet == NULL)
die("InternetOpen()");

printf("Requesting url...\n");
url = InternetOpenUrl(internet,
requesturl,
NULL,
0,
INTERNET_FLAG_PRAGMA_NOCACHE,
0);
if (url == NULL)
die("InternetOpenUrl()");

buf = malloc(BUFFER_SIZE + 1);
if (buf == NULL)
die("Unable to allocate memory for receive buffer");

printf("Saving file");
while (InternetReadFile(url,
buf,
BUFFER_SIZE,
&bytesread))
{
if (bytesread == 0) break;

if (!usestdout)
{
WriteFile(file,
buf,
bytesread,
&byteswritten,
NULL);

putchar('.');
}
else
//fwrite( const void *buffer, size_t size, size_t count, FILE *stream );
fwrite(buf, bytesread, 1, stdout);
}
putchar('\n');

free(buf);
InternetCloseHandle(url);
InternetCloseHandle(internet);
CloseHandle(file);

printf("Done.\n");

return 0;
}

void usage(void)
{
fprintf(stderr, "http rip - Chad Osgood\n\nusage: httprip url filename\n");
exit(EXIT_FAILURE);
}

void die(const char *message)
{
fprintf(stderr, "%s", message);
exit(EXIT_FAILURE);
}