#!/bin/sh
python3 webfilecreate.py
g++ project1.cpp && ./a.out
