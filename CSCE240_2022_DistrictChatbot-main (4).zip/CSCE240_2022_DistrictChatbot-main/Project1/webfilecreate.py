import requests

URL = "https://www.scstatehouse.gov/member.php?code=1002272607"

page = requests.get(URL)
file= open("district49site.txt","a+")
file.truncate(0)
file.write(page.text)

#print(page.text)#prints pulled text to terminal

file.close()