  #include <iostream>

int main() {
    std::cout << "Hello World!";
    
   int  var;    int  *ptr;   // pointer 
   int  **pptr; // pointer to pointer 
 
   var = 1000; 
 
   // Taking address of var    ptr = &var; 
 
   // Taking the address of ptr     pptr = &ptr; 
 
   // Print statement 
  std::cout << "*ptr shows value of:" << *ptr << std::endl;    
  std::cout << "**pptr shows value of:" << **pptr << std::endl; 
    return(0);
}